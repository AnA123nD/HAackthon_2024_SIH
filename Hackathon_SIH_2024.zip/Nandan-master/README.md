# Nandan
Android app made during Rural Development hackathon

• Nandan is a platform which provides all the necessary information to the mother. For example about preconception care and prenatal care. It gives information about the diet also what is good for the mother and for her child.

• It also shows all nearby child healthcare centers on the map with their details.

• Also there is a vaccination tracker which tracks the vaccination given to the child.

• A section is there which tells about recent policies of Government related to child care.

• A real time web platform for visualization of data.

# Backend

- Google Firebase Database and Storage

# Screenshots

<img src="screenshots/Screenshot_2018-02-27-19-30-55.jpg" height="500" width="300"> <img src="screenshots/Screenshot_2018-02-27-19-31-26.jpg" height="500" width="300"> 

<img src="screenshots/Screenshot_2018-02-27-19-31-33.jpg" height="500" width="300"> <img src="screenshots/Screenshot_2018-02-27-19-31-38.jpg" height="500" width="300">

<img src="screenshots/Screenshot_2018-02-27-19-32-28.jpg" height="500" width="300"> <img src="screenshots/Screenshot_2018-02-27-19-31-48.jpg" height="500" width="300">

<img src="screenshots/Screenshot_2018-02-27-19-32-42.jpg" height="500" width="300"> <img src="screenshots/Screenshot_2018-02-27-19-32-17.jpg" height="500" width="300"> 
<img src="screenshots/Screenshot_2018-02-27-19-32-48.jpg" height="500" width="300">
