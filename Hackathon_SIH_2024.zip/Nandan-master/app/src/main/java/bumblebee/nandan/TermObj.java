package bumblebee.nandan;

/**
 * Created by anuragsharma on 08/10/17.
 */

public class TermObj {
    private String name, desc;

    public TermObj(String n, String d){
        name = n;
        desc = d;
    }

    public String getName() {
        return name;
    }

    public String getDesc() {
        return desc;
    }
}
