package bumblebee.nandan;

/**
 * Created by anuragsharma on 27/02/18.
 */

public class BabyData {

    String name, contact, disease, weight, location, date,email;

    public BabyData(String name, String contact,String disease,String weight, String location, String date,String email){

        this.name = name;
        this.contact = contact;
        this.disease = disease;
        this.weight = weight;
        this.location = location;
        this.date = date;
        this.email = email;

    }
}
